"""Grid subsampling of the eleven-setpoint reference grid (Table 4, Fig. 6).

Every contiguous window of k = 3 ... 11 setpoints of the mid state (state 5, OCV ~3.67 V,
nominal SoC 50 %) is regressed separately. The 95 % CI uses the exact Student-t quantile
t(0.975, k-2). Writes out/unisa_subsampling.csv for R_ct (the manuscript's table) and
out/unisa_subsampling_sum.csv for the swap-invariant sum R_SEI + R_ct (robustness check).
"""
import os
import numpy as np, pandas as pd
from scipy.stats import linregress, t as student_t
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '00_paths.py')).read())
df = pd.read_csv(os.path.join(OUT, 'unisa_fits.csv'))
mid = 5   # mid-state index (OCV ~3.67 V)
gg = df[df.ridx == mid].sort_values('T')
soc = float(gg['soc'].median()) if 'soc' in gg.columns and gg['soc'].notna().any() else float('nan')
TK = gg['T'].values + 273.15


def subsample(R):
    rows = []; n = len(TK)
    for k in range(3, n+1):
        for i in range(0, n-k+1):
            s = slice(i, i+k)
            reg = linregress(1/TK[s], np.log(1/R[s]))
            t_critical = student_t.ppf(0.975, df=k-2)  # two-sided 95% CI for the slope
            rows.append(dict(SOC=soc, k=k, Tmin=TK[s][0]-273.15, span=TK[s][-1]-TK[s][0],
                             Ea=-reg.slope*8.314/1000,
                             CI=reg.stderr*8.314/1000*t_critical))
    return pd.DataFrame(rows)


for R, name, label in [(gg['Rct'].values, 'unisa_subsampling.csv', 'R_ct'),
                       ((gg['Rsei'] + gg['Rct']).values, 'unisa_subsampling_sum.csv', 'R_SEI + R_ct')]:
    sub = subsample(R); sub.to_csv(os.path.join(OUT, name), index=False)
    print(f"{label}:")
    for k in sorted(sub.k.unique()):
        s = sub[sub.k == k]
        print(f"  k={k:2d}: Ea in [{s.Ea.min():6.1f},{s.Ea.max():6.1f}]  median CI ±{s.CI.median():5.1f}")
